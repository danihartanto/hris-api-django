from .base import *

DEBUG = False