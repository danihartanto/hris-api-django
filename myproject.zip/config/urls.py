from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

from drf_spectacular.views import SpectacularAPIView, SpectacularSwaggerView

urlpatterns = [
    path("admin/", admin.site.urls),

    path("api/schema/", SpectacularAPIView.as_view(), name="schema"),
    path("api/docs/", SpectacularSwaggerView.as_view(url_name="schema"), name="docs"),

    path("api/accounts/", include("apps.accounts.urls")),
    path("api/employees/", include("apps.employees.urls")),
    path("api/", include("apps.employees.urls")),
    path("api/", include("apps.attendance.urls")),
    path("api/leave/", include("apps.leave.urls")),
    path("api/payroll/", include("apps.payroll.urls")),
    
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
